bm_menu_inventory_tradable_all = "ทั้งหมด",--All
bm_menu_inventory_tradable_drills = "สว่าน",--Drills
bm_menu_inventory_tradable_safes = "ตู้เซฟ",--Safes
bm_menu_inventory_tradable_weapon_skins = "สกินปืน",--Weapon Skins
bm_menu_btn_preview_weapon_cosmetic = "ตรวจสอบสกินปืน",--Preview Weapon skin
bm_menu_btn_sell_tradable = "นำไปขายในตลาด",--Sell On Maket Community
menu_ti_steam_open_container = "เปิดตู้เซฟ",--Open Safe
