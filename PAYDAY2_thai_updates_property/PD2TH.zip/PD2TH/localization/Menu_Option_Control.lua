menu_camera_sensitivity = "ความไวของมุมมอง",--LOOK SENSITIVITY
menu_camera_sensitivity_help = "ความไวของมุมมอง",--Increase or decrease the responsiveness of your look input.
menu_camera_zoom_sensitivity = "ความไวของมุมมองตอนเล็ง",--AIMING SENSITIVITY
menu_camera_zoom_sensitivity_help = "ความไวของมุมมองตอนเล็ง",--INCREASE OR DECREASE THE RESPONSIVENESS OF YOUR LOOK INPUT DURING AIMING.
menu_toggle_zoom_sensitivity = "ตั้งค่าการเล็งแบบเฉพาะ",--SEPARATE AIMING SETTING
menu_toggle_zoom_sensitivity_help = "เปิดใช้งานการตั้งค่าการตอบสนองของเมาส์ที่แยกจากกันในระหว่างการเล็ง",--Enable separate mouse responsiveness setting during aiming.
menu_invert_camera_vertically = "สลับแกน Y",--INVERT Y-AXIS
menu_invert_camera_vertically_help = "สลับแกน Y ของเมาส์",--Turn invert Y-Axis on or off.
menu_hold_to_steelsight = "กดค้างเพื่อเล็งปืน",--HOLD TO AIM
menu_hold_to_steelsight_help = "คลิกขวาค้างเพื่อเล็งปืนหากปิดการตั้งค่านี้จะคลิกครั้งเดียวเพื่อเล็งคลิกอีกทีเพื่อออกจากการเล็ง",--Turn hold button to aim through sights on or off.
menu_hold_to_run = "กดค้างเพื่อวิ่ง",--HOLD TO RUN
menu_hold_to_run_help = "คลิกชิฟค้างเพื่อวิ่งหากปิดการตั้งค่านี้จะกดครั้งเดียวเพื่อวิ่งกดอีกทีเพื่อเดิน",--Turn hold button to keep running on or off.
menu_hold_to_duck = "กดค้างเพื่อนั่ง",--HOLD TO CROUCH
menu_hold_to_duck_help = "คลิกคอนโทรค้างเพื่อนั่งหากปิดการตั้งค่านี้จะกดครั้งเดียวเพื่อนั่งกดอีกทีเพื่อยืน",--Turn hold button to keep crouching on or off.
menu_customize_controller = "ตั้งค่าปุ่มกด",--EDIT KEYS
menu_customize_controller_help = "ตั้งค่าปุ่มกดของคุณ",--Choose your preferred keyboard and mouse layout.
menu_control_option_default = "คืนการตั้งค่าดังเดิม",--DEFAULT CONTROL OPTIONS
menu_control_option_default_help = "เรียกคืนการตั้งค่าดังเดิมในส่วนของการควบคุม",--Resets control options to their default state.



