menu_packet_throttling = "การควบคุมปริมาณข้อมูล",--Packet Throttling
menu_packet_throttling_help = "การควบคุมปริมาณการส่งข้อมูลแต่จะทำให้เซิฟเวอร์แลคหรือตอบสนองช้าลง",--Network packets will be sent in groups to reduce the network load, but increase delays.
menu_net_forwarding = "ใช้งานการฟอเวิดพอต",--Forwarding
menu_net_forwarding_help = "ใช้งานการฟอเวิดพอตเมื่อเชิ่มต่อโดยตรงกับผู้เล่นอื่นไม่ได้",--Network packets may be sent through other players if direct connection fails.
menu_net_use_compression = "ใช้งานการบีบอัดข้อมูล",--Use Compression
menu_net_use_compression_help = "ใช้งานการบีบอัดให้เกมลดการใช้อินเตอร์เน็ตน้อยลง",--Compresses network data before sending which reduces the network load, but makes the game slightly heavier.
menu_network_option_default = "คืนการตั้งค่าดังเดิม",--DEFAULT NETWORK OPTIONS
menu_network_option_default_help = "เรียกคืนการตั้งค่าดังเดิมในส่วนของเน็ตเวิร์ค",--Resets network options to their default state.