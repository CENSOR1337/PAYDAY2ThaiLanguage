menu_crew_management = "จัดการทีมบอท",--
bm_menu_masks = "หน้ากากของบอท",--
bm_menu_primaries = "ปืนของบอท",--
bm_menu_ability = "ความสามารถของบอท",--
bm_menu_skill = "สกิลของบอท",--
