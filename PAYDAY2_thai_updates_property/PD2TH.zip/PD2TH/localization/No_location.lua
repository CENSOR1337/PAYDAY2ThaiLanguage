debug_mission_end_continue = "กด $CONTINUE; เพื่อไปที่ล็อบบี้",--$CONTINUE; Continue to lobby
victory_client_waiting_for_server = "กรุณารอ",--WAITING FOR SERVER
failed_disconnected_continue = "กด $CONTINUE; เพื่อไปที่เมนู",--$CONTINUE; Continue to menu
menu_button_continue = "ไปที่ล็อบบี้",--Continue to lobby
menu_crewpage = "วางแผน",--Planning Phase
