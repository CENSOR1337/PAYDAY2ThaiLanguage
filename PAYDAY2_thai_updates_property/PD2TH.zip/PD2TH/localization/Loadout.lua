menu_escape = "คุณต้องหลบหนี!",--Escape!
menu_job_overview = "ภาพรวมของงานจ้าง",--Job Overview
menu_description = "แผนของเบน",--Bain's Plan
menu_assets = "อุปกรณ์เพิ่มเติม",--Assets
menu_loadout = "ชุดอุปกรณ์",--Loadout
menu_team_loadout = "อุปกรณ์ของเพื่อนร่วมทีม",--Crew Setup
menu_jukebox = "ซาวแทรค",--Soundtrack
debug_loading_level = "กำลังโหลด",--Loading
menu_waiting_is_joining = "กำลังเข้าร่วมเกม",--JOINING
menu_waiting_is_ready = "พร้อม",--READY
menu_waiting_is_not_ready = "รีบๆหน่อยเพื่อนรออยู่",--NOT READY
menu_lobby_player_slot_available = "ที่ว่างสำหรับผู้เล่น",--PLAYER SLOT AVAILABLE
menu_loadout_empty = "ว่าง",--Empty
menu_click_when_ready = "กดตรงนี้เมื่อคุณพร้อม",--Click here when ready
--MUSIC
menu_jukebox_playlist_all = "สุ่มแทรคเพลง",--Random track
menu_jukebox_random_heist_playlist = "สุ่มแทรคเพลงจากเพลงในด่าน",--Random from custom heist playlist
menu_jukebox_playlist_heist = "ปรับแต่งแทรคเพลงในด่าน",--Custom heist track
menu_jukebox_server_choice = "ปรับให้เหมือนหัวหน้าห้อง",--Same as host
menu_jukebox_your_choice = "ปรับแต่งแทรคเพลง",--Custom track:
--PrePlanning
menu_preplanning_title = "วางแผน",--PrePlanning: $level;
menu_preplanning_enter = "เข้าสู่โหมดวางแผน",--Enter Preplanning
menu_pp_loading = "กำลังโหลดโหมดวางแผน...",--Loading Preplanning...
menu_waiting_for_players_progress = "กำลังรอ $player_name; โหลดไปแล้ว $prog;",--Waiting for $player_name; $prog;%

