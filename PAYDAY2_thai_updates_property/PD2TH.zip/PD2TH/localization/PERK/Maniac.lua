--Maniac Perk Deck
menu_st_spec_14 = "",--Maniac
menu_st_spec_14_desc = "",--The Maniac Perk Deck is the embodiment of crazy and to never accept bad odds in moments of danger. By pushing through and constantly deal damage, your fellow heisters will be granted a temporary shield making all of you feel Jimmy's invulnerable spirit.
menu_deck14_1 = "",--Excitement
menu_deck14_1_desc = "##$multiperk;## จากดาเมจที่สร้างได้จะเปลี่ยนเป็น Hysteria สูงสุดครั้งละ ##$multiperk2;## ใน ##$multiperk3;## วินาที. สูงสุดเก็บได้ ##$multiperk4;##.$NL;$NL;Hysteria Stacks$NL;You gain ##$multiperk5;## damage absorption for every ##$multiperk6;## stacks of Hysteria. Hysteria Stacks decays ##$multiperk7;## every ##$multiperk8;## seconds.",--##$multiperk;## of damage you deal is converted into Hysteria Stacks, up to ##$multiperk2;## every ##$multiperk3;## seconds. Max amount of stacks is ##$multiperk4;##.$NL;$NL;Hysteria Stacks$NL;You gain ##$multiperk5;## damage absorption for every ##$multiperk6;## stacks of Hysteria. Hysteria Stacks decays ##$multiperk7;## every ##$multiperk8;## seconds.
menu_deck14_3 = "",--Outburst
menu_deck14_3_desc = "",--Members of your crew also gains the effect of your Hysteria Stacks.$NL;$NL;Hysteria Stacks from multiple crew members do not stack and only the stacks that gives the highest damage absorption will have an effect.
menu_deck14_5 = "",--Fervor
menu_deck14_5_desc = "",--Change the decay of your Hysteria Stacks to ##$multiperk;## every ##$multiperk2;## seconds.
menu_deck14_7 = "",--Recklessness
menu_deck14_7_desc = "",--Change the damage absorption of your Hysteria Stacks on you and your crew to ##$multiperk;## damage absorption for every ##$multiperk2;## stacks of Hysteria.
menu_deck14_9 = "",--Insanity
menu_deck14_9_desc = "",--Damage absorption from Hysteria Stacks on you is increased by ##$multiperk;##.$NL;$NL;Deck Completion Bonus: Your chance of getting a higher quality item during a PAYDAY is increased by ##$multiperk2;##.
