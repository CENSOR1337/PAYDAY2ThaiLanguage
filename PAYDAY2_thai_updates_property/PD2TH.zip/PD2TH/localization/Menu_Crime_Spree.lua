menu_cs_level = "",
menu_cs_select_modifier = "",
menu_cs_get_rewards = "",
menu_cs_suspend_spree = "",