bm_menu_btn_equip_weapon= "ใช้งานอาวุธ",--Equip weapon
bm_menu_btn_mod= "ปรับแต่งอาวุธ",--Modify weapon
bm_menu_btn_preview= "ตรวจลักษณะของอาวุธ",--Preview weapon
bm_menu_btn_sell= "ขายอาวุธ",--Sell weapon
bm_menu_btn_preview_with_mod = "ตรวจลักษณะของอาวุธแบบปรับแต่ง",--Preview weapon with mod
bm_menu_btn_preview_no_mod = "ตรวจลักษณะของอาวุธแบบไม่ปรับแต่ง",--Preview weapon without mod
bm_menu_btn_buy_selected_weapon = "ซื้อปืน",--Buy weapon
bm_menu_btn_buy_new_weapon = "ซื้อปืนใหม่",--Buy new weapon
bm_menu_btn_move_weapon = "ย้ายช่องปืน",--Move Weapon
bm_menu_btn_swap_weapon = "สลับช่องปืน",--Swap Weapon
bm_menu_btn_place_weapon = "วางปืน",--Place Weapon
bm_menu_btn_stop_move = "ยกเลิก",--Cancel

