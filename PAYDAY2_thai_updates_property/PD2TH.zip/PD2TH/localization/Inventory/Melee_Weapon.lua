bm_menu_btn_equip_melee_weapon = "ใช้งานอาวุธ",--Equip melee weapon
bm_menu_btn_preview_melee_weapon = "ตรวจลักษณะอาวุธ",--Preview melee weapon
