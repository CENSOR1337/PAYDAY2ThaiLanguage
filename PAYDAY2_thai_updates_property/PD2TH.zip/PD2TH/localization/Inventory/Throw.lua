bm_menu_btn_equip_grenade = "ใช้งานอาวุธขว้าง",--Equip Throwable
bm_menu_btn_preview_grenade = "ตรวจลักษณะอาวุธขว้าง",--Preview Throwable
