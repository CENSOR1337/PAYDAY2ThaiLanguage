menu_skillpoints = "เหลือพ้อยท์ทั้งหมด",--Remaining Skill points
menu_mouse_invest = "เพื่อเรียนรู้ทักษะ",--to Invest skillpoint
menu_st_switch_skillset = "กด $BTN_SKILLSET; เพื่อเปลี่ยนเซ็ตทักษะ",--$BTN_SKILLSET; to switch skillset
menu_mouse_refund = "เพื่อเรียกคืนพ้อยท์",--to Refund skillpoint